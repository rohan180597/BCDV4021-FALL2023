import React from 'react';
import Greeter from './Greeter';
function App(){
  return(
    <div>
    <h1>Welcome to my React app</h1>
    <Greeter /> {/*Use the Greeter component*/}
    </div>
  );
}
export default App;